package com.example.complaintsystems;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HistoryAdminActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
